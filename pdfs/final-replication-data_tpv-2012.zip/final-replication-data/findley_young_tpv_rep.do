******************************************
* More Combatant Groups, More Terror?:   *
* Empirical Tests of an Outbidding Logic *
* Authors: Mike Findley & Joe Young      *
* Date: 5/29/12                          *
* Replication materials for TPV          *
******************************************

*you will need to acquire the relogit command from:
*http://www.stanford.edu/~tomz/software/relogit.zip

set more off
cd "SET PATH HERE"


* GTD Actors (all years)
use "suicide-data-collapsed-with-gtd-groups-all-70-97-years.dta", clear

nbreg  tarct totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable, cluster(cowcode) nolog
nbreg  tarct totalGrpsGTD12, cluster(cowcode) nolog

nbreg  tarct totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year<1998, cluster(cowcode) nolog
nbreg  tarct totalGrpsGTD12 if year<1998, cluster(cowcode) nolog

nbreg  tarct totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year > 1997, cluster(cowcode) nolog
nbreg  tarct totalGrpsGTD12 if year > 1997, cluster(cowcode) nolog

relogit tarctdm totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable 

zinb  tarct totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable, inflate(totalGrpsGTD12 fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable) cluster(cowcode) nolog




* GTD Actors (armed conflict years)
use "suicide-data-collapsed-with-gtd-groups-during-civil-wars.dta", clear

nbreg  tarct totalGrpsYear fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable, robust cluster(cowcode) nolog
nbreg  tarct totalGrpsYear, robust cluster(cowcode) nolog

nbreg  tarct totalGrpsYear fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year<1998, robust cluster(cowcode) nolog
nbreg  tarct totalGrpsYear if year<1998, robust cluster(cowcode) nolog

nbreg  tarct totalGrpsYear fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year > 1997, robust cluster(cowcode) nolog
nbreg  tarct totalGrpsYear if year > 1997, robust cluster(cowcode) nolog

relogit tarctdm totalGrpsYear fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable 

zinb  tarct totalGrpsYear, inflate(totalGrpsYear) robust cluster(cowcode) nolog


* Lenient Veto Players Maxed (armed conflict years)

nbreg  tarct lenientMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable, robust cluster(cowcode) nolog
nbreg  tarct lenientMaxed, robust cluster(cowcode) nolog

nbreg  tarct lenientMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year<1998, robust cluster(cowcode) nolog
nbreg  tarct lenientMaxed if year<1998, robust cluster(cowcode) nolog

nbreg  tarct lenientMaxed if year > 1997, robust cluster(cowcode) nolog
*will not converge with control variables

relogit tarctdm lenientMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable 

zinb  tarct lenientMaxed, inflate(lenientMaxed) robust cluster(cowcode) nolog
*will not converge with control variables


* Uppsala Actors Maxed (armed conflict years)

nbreg  tarct uppsalaMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable, robust cluster(cowcode) nolog
nbreg  tarct uppsalaMaxed , robust cluster(cowcode) nolog

nbreg  tarct uppsalaMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year<1998, robust cluster(cowcode) nolog
nbreg  tarct uppsalaMaxed if year<1998, robust cluster(cowcode) nolog

nbreg  tarct uppsalaMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable if year > 1997, robust cluster(cowcode) nolog
nbreg  tarct uppsalaMaxed if year > 1997, robust cluster(cowcode) nolog

relogit tarctdm uppsalaMaxed fhpfdm fhnddm lnencap lnpop islamdm pasttarctavg  globct fhpfdmmar  fhnddmmar marctrd durable 

zinb  tarct uppsalaMaxed, inflate(uppsalaMaxed) robust cluster(cowcode) nolog
*will not converge with control variables




* THE RESULTS FOR ALL TERRORISM
use "all-terrorism-data-collapsed-during-civil-wars.dta", clear

nbreg totalAttacks lenientMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict, cluster(cowcode) nolog
nbreg totalAttacks lenientMaxed, cluster(cowcode) nolog

nbreg totalAttacks lenientMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict if year < 1998, cluster(cowcode) nolog
nbreg totalAttacks lenientMaxed if year< 1998, cluster(cowcode) nolog

nbreg totalAttacks lenientMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict if year > 1997, cluster(cowcode) nolog
nbreg totalAttacks lenientMaxed if year> 1997, cluster(cowcode) nolog

zinb totalAttacks lenientMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict, inflate(lenientMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict) cluster(cowcode) nolog


* uppsala maxed

nbreg totalAttacks uppsalaMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict , cluster(cowcode) nolog 
nbreg totalAttacks uppsalaMaxed , cluster(cowcode) nolog

nbreg totalAttacks uppsalaMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict if year < 1998, cluster(cowcode) nolog 
nbreg totalAttacks uppsalaMaxed if year < 1998, cluster(cowcode) nolog

nbreg totalAttacks uppsalaMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict if year > 1997, cluster(cowcode) nolog 
nbreg totalAttacks uppsalaMaxed if year > 1997, cluster(cowcode) nolog

zinb totalAttacks uppsalaMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict, inflate(uppsalaMaxed cinc polity2lag polity2lagsquare gdpenl ethnicconflict) cluster(cowcode) nolog 


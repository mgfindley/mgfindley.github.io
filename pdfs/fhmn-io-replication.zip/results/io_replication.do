clear

set more off 

capture cd "SET PATH HERE"



use "io_fhmn_replication.dta", clear


*** FIGURE 1

gen outcome = .
gen group = .
gen mech=.
gen diff = .
gen difflo =.
gen diffhi=.

  
label define outc2 9 "Strong support" 8 "Tell support" 7 "Will. to sign" 6 "Sign petition" ///
   5 "Will. to Sign Pres." 4 "Sign pres." 3 "Tell constituents" 2 "Rally local offic." ///
   1 "Coord. w/peers" 11 "Sent SMS" 12 "Willing to SMS" 13 "Sign petition" 14 "Will. to sign" 15 "Tell support" 16 "Strong support", modify


   
preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
ttest `: word `j' of `vars'' if  mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`k'
replace diffhi = diff + (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace difflo = diff - (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace group = 1 if _n==`j'+`k'

local k = `k'+2
}


local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`k'
replace diffhi = diff + (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace difflo = diff - (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace group = 2 if _n==`j'+`k'


local k = `k'+2
}


label val outcome outc2
twoway rcap  diffhi difflo outcome if group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if  group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if  group==1, mcolor(maroon)   ///
   title("Differences in means") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save "figure1.gph" , replace
graph export "figure1.pdf" , replace
 

restore





*** FIGURE 2

** Manipulation Check
preserve
local k = 0


local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if mass==1 & manip_donor==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`k'
replace diffhi = diff + (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace difflo = diff - (invttail(r(df_t),.05))*r(se) if _n==`j'+`k'
replace group = 2 if _n==`j'+`k'


local k = `k'+2
}


label val outcome outc2
twoway rcap  diffhi difflo outcome if group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   legend(label(1 "Mass")  order(1)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: Manipulation check") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save "figure2.gph", replace
graph export "figure2.pdf", replace
 

restore
 


 *** FIGURE 3

 
*** Difference in Means for Corruption/Clientelism Mechanism
 

preserve
gen mostaid = aid_corrup<=2
replace mostaid = . if aid_corrup==.

local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if client_allies  == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.05))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.05))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}


local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if agree_corr==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.05))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.05))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}


label val outcome outc2
 
twoway rcap  diffhi difflo outcome if mech==1 & group==1, horiz ylab(1/9 11/16, val angle(0) nolabels) ///
   || rcap  diffhi difflo outcome if mech==1 & group==2, horiz legend(off) ytitle("")   ///
	xtitle("Difference in means") /// 
   || scatter outcome diff if mech==1 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==1 & group==2, mcolor(maroon) name(c1, replace)   ///
   title("Corruption/clientelism") 

 
twoway rcap  diffhi difflo outcome if mech==0 & group==1, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==0 & group==2, horiz  legend(off) ytitle("") ///
  xtitle("Difference in means")  ///
   || scatter outcome diff if mech==0 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==0 & group==2, mcolor(maroon)  name(c0, replace)  ///
   title("No corruption/clientelism") 

#delim ;
twoway rcap  diffhi difflo outcome if mech==0 & group==1, horiz ylab(1/9 11/16, val angle(0) labsize(small)) 
   || rcap  diffhi difflo outcome if mech==0 & group==2, horiz 
   legend(label(1 "MPs") label(2 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means")
   || scatter outcome diff if mech==0 & group==1, mcolor(navy)  xline(0, lcolor(black)) 
   || scatter outcome diff if mech==0 & group==2, mcolor(maroon)
nodraw name(corr_leg, replace) xtitle("") title("")  xscale(off) yscale(off); 
#delim cr
_gm_edit .corr_leg.plotregion1.draw_view.set_false
_gm_edit .corr_leg.ystretch.set fixed

 
graph combine c0 c1 ,  name(c , replace)
graph combine c corr_leg , cols(1) note("Pos. difference = treatment>control; neg. difference = control>treatment", size(vsmall))
graph save "figure3.gph", replace
graph export "figure3.pdf" , replace 
graph export "figure3.svg" , replace height(540) width(720)

restore

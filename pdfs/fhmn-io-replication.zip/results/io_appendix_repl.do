clear

set more off 

capture cd "SET PATH HERE"

use io_fhmn_replication.dta , clear
cd results


recode ethnic_attach (-9=.) (-1=.)
recode ethnic_attach (0/2=1) (.=.) (else=0) , gen(nationalist2)


gen govtimplement = .
replace govtimplement = 1 if effec_org < 3
replace govtimplement = 0 if effec_org == 3 | effec_org == 4 | effec_org == 5

gen foreignmedia = .
replace foreignmedia = 1 if media_type_o1 == 1
replace foreignmedia = 0 if media_type_o1 > 1

replace runyankole = 1 if ethnicity == 20 & mp == 1
replace runyankole = 0 if ethnicity != 20 & mp == 1 & ethnicity != -9 & ethnicity != .


 gen q70 = cond(dom_allies<=2,1,cond(dom_allies==4 | dom_allies==5,0,.))
  label define q70 1 "Gov helps neediest" 0 "Gov helps allies"
  label val q70 q70
 
gen q71 = cond(domfor_allies<=2,1,cond(domfor_allies==4 | domfor_allies==5,0,.))

label define q71 1 "Aid helps neediest" 0 "Gov helps neediest"
  label val q71 q71

gen q72 = cond(domaid_waste<=2,1,cond(domaid_waste==4 | domaid_waste==5,0,.))

label define q72 1 "Aid least waste" 0 "Gov least waste"
  label val q72 q72


gen q73 = cond(domaid_transparent<=2,1,cond(domaid_transparent==4 | domaid_transparent==5,0,.))

label define q73 1 "Aid transparent" 0 "Gov transparent"
  label val q73 q73


gen q74 = cond(domaid_matchneed<=2,1,cond(domaid_matchneed==4 | domaid_matchneed==5,0,.))
label define q74 1 "Aid match needs" 0 "Gov match needs"
  label val q74 q74

   
 qui sum knowledge if mass==1, meanonly
gen high_knowl = knowledge>r(mean) if mass==1
replace high_knowl = . if knowledge==.

qui sum rel_pov if mass==1, meanonly    
gen high_pov = rel_pov>r(mean) if mass==1
replace high_pov = . if rel_pov==.


  
gen outcome = .
gen group = .
gen mech=.
gen diff = .
gen difflo =.
gen diffhi=.

  
label define outc2 9 "Strong support" 8 "Tell support" 7 "Will. to sign" 6 "Sign petition" ///
   5 "Will. to Sign Pres." 4 "Sign pres." 3 "Tell constituents" 2 "Rally local offic." ///
   1 "Coord. w/peers" 11 "Sent SMS" 12 "Willing to SMS" 13 "Sign petition" 14 "Will. to sign" 15 "Tell support" 16 "Strong support", modify

   gen christian=.
replace christian=1 if religion==1 | religion==2 | religion==5 | religion==6
replace christian=0 if religion==3 | religion==4
*nois ta christian

gen muslim=.
replace muslim=1 if religion ==3
replace muslim=0 if religion==1 | religion==2 | religion==4 | religion==5 | religion==6
*nois ta muslim, mis


cd "/Users/`c(username)'/Dropbox/Uganda/Writing/Elite v Mass Paper/IO Submission - Elites/2nd-Revise-Resubmit/results/appendix"   
 *** TABLE A1
 
 

 *** TABLE A2
 gen supportaid_control=abs(treat_control-2)

 nois logit supportaid_control education male age nrm christian muslim  high_pov high_knowl foreignmedia runyankole nationalist i.region  if mass==1 & age>1, robust
est store all

logit supportaid_control nrm male /*uas_mp dist_mp */ foreignmedia runyankole nationalist  if mp==1, cluster(sub_id)
 est store rmp
 
estout all rmp using taba2.txt , stats(N , fmt(%9.0f)) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) replace
  

   *** TABLE A3
*panel A
*masses
*ttest exp if mass==1, by(treat_control) unequal
ttest strong_supp if mass==1, by(treat_control) unequal
ttest tell_support if mass==1, by(treat_control) unequal
ttest sign_pet if mass==1, by(treat_control) unequal
ttest enum_petition if mass==1, by(treat_control) unequal
ttest sms_willing if mass==1, by(treat_control) unequal
ttest sms if mass==1 & have_phone==1, by(treat_control) unequal


*MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1, by(treat_control) unequal
ttest tell_support if mp==1, by(treat_control) unequal
ttest sign_pet if mp==1, by(treat_control) unequal
ttest enum_petition if mp==1, by(treat_control) unequal
ttest pres_sign if mp==1, by(treat_control) unequal
ttest enum_pres if mp==1, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1, by(treat_control) unequal
ttest rally_locals if mp==1, by(treat_control) unequal
ttest coor_peers if mp==1, by(treat_control) unequal

*** TABLE A4

ttest strong_support if manip_donor==1 , by(treat_control) unequal
ttest tell_support if manip_donor==1 , by(treat_control) unequal
ttest sign_pet if manip_donor==1 , by(treat_control) unequal
ttest enum_petition if manip_donor==1 , by(treat_control) unequal
ttest sms_willing if manip_donor==1 , by(treat_control) unequal
ttest sms if have_phone==1 & manip_donor==1 , by(treat_control) unequal

gen manip_new = .
	replace manip_new = 1 if manip_2 >= 1 & manip_2 <= 6 // guessed foreign donor
	replace manip_new = 0 if manip_2 == -5 // guessed govt 
	replace manip_new = 0 if manip_2 == -8 // guessed govt

ivregress 2sls strong_support (manip_new=aid_control) if mass == 1, robust
ivregress 2sls tell_support   (manip_new=aid_control) if mass == 1, robust
ivregress 2sls sign_pet  (manip_new=aid_control) if mass == 1, robust
ivregress 2sls enum_petition  (manip_new=aid_control) if mass == 1, robust
ivregress 2sls sms_willing  (manip_new=aid_control) if mass == 1, robust
ivregress 2sls sms (manip_new=aid_control) if mass == 1 & have_phone == 1, robust

*** TABLE A5

** client_allies 

*MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1 & client_allies==1, by(treat_control) unequal
ttest strong_supp if mp==1 & client_allies==0, by(treat_control) unequal

ttest tell_support if mp==1 & client_allies==1, by(treat_control) unequal
ttest tell_support if mp==1 & client_allies==0, by(treat_control) unequal
ttest sign_pet if mp==1 & client_allies==1, by(treat_control) unequal
ttest sign_pet if mp==1 & client_allies==0, by(treat_control) unequal
ttest enum_petition if mp==1 & client_allies==1, by(treat_control) unequal
ttest enum_petition if mp==1 & client_allies==0, by(treat_control) unequal
ttest pres_sign if mp==1 & client_allies==1, by(treat_control) unequal
ttest pres_sign if mp==1 & client_allies==0, by(treat_control) unequal
ttest enum_pres if mp==1 & client_allies==1, by(treat_control) unequal
ttest enum_pres if mp==1 & client_allies==0, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1 & client_allies==1, by(treat_control) unequal
ttest tell_constits if mp==1 & client_allies==0, by(treat_control) unequal
ttest rally_locals if mp==1 & client_allies==1, by(treat_control) unequal
ttest rally_locals if mp==1 & client_allies==0, by(treat_control) unequal
ttest coor_peers if mp==1 & client_allies==1, by(treat_control) unequal
ttest coor_peers if mp==1 & client_allies==0, by(treat_control) unequal


*** TABLE A6
ttest strong_support if agree_corr==1 & mass==1, by(treat_control) unequal
ttest strong_support if agree_corr==0 & mass==1, by(treat_control) unequal
ttest tell_support if agree_corr==1 & mass==1, by(treat_control) unequal
ttest tell_support if agree_corr==0 & mass==1, by(treat_control) unequal
ttest sign_pet if agree_corr==1 & mass==1, by(treat_control) unequal
ttest sign_pet if agree_corr==0 & mass==1, by(treat_control) unequal
ttest enum_petition if agree_corr==1 & mass==1, by(treat_control) unequal
ttest enum_petition if agree_corr==0 & mass==1, by(treat_control) unequal
ttest sms_willing if agree_corr==1 & mass==1 & have_phone==1, by(treat_control) unequal
ttest sms_willing if agree_corr==0 & mass==1 & have_phone==1, by(treat_control) unequal
ttest sms if agree_corr==1 & mass==1 & have_phone==1, by(treat_control) unequal
ttest sms if agree_corr==0 & mass==1 & have_phone==1, by(treat_control) unequal

  
*** FIGURE A1 & A2

preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if foreignmedia == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if foreignmedia==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}

label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==1 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==1 & group==1, mcolor(maroon)   ///
   title("Differences in means: Watch foreign media") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA2.gph , replace
 graph export figureA2.pdf , replace
 
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==0 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==0 & group==1, mcolor(maroon)   ///
   title("Differences in means: Do not watch foreign media") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA1.gph , replace
 graph export figureA1.pdf , replace
 restore


*** FIGURE A3 & A4
 *** PARTISANSHIP
 
preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if nrm == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if nrm==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}

label val outcome outc2
 
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==0 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==0 & group==1, mcolor(maroon)   ///
   title("Differences in means: Not NRM member") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA3.gph , replace
 graph export figureA3.pdf , replace
 
 twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==1 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==1 & group==1, mcolor(maroon)   ///
   title("Differences in means: NRM member") note("Pos. difference = treatment>control; neg. difference = control>treatment")
  graph save figureA4.gph , replace
 graph export figureA4.pdf , replace

 restore
 
 *** FIGURE A5 & A6
 
 *** ETHNICITY 
 
 preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if runyankole == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if runyankole==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}

label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==1 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==1 & group==1, mcolor(maroon)   ///
   title("Differences in means: Runyankole") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA6.gph , replace
 graph export figureA6.pdf , replace
 
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==0 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==0 & group==1, mcolor(maroon)   ///
   title("Differences in means: Not Runyankole") note("Pos. difference = treatment>control; neg. difference = control>treatment")
  graph save figureA5.gph , replace
 graph export figureA5.pdf , replace
 restore

 
 
 *** FIGURE A7 & A8
 
 *** NATIONALISM
 preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if nationalist == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if nationalist==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}

label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==1 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==1 & group==1, mcolor(maroon)   ///
   title("Differences in means: Nationalist") note("Pos. difference = treatment>control; neg. difference = control>treatment")
  graph save figureA8.gph , replace
 graph export figureA8.pdf  , replace
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(1/9 11/16, val angle(0) labsize(small)) ///
   || rcap  diffhi difflo outcome if mech==0 & group==1, horiz ///
   legend(label(2 "MPs") label(1 "Mass")  order(1 2)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   || scatter outcome diff if mech==0 & group==1, mcolor(maroon)   ///
   title("Differences in means: Not Nationalist") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA7.gph , replace
 graph export figureA7.pdf , replace
 restore

 *** FIGURE A9 & A10
    *** FORMER MPs
 
preserve
local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if former_mp == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==1, horiz ylab(1/9 , val angle(0) labsize(small)) ///
   legend(label(1 "MPs") /*label(1 "Mass") */ order(1 )) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: Former MPs") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA9.gph , replace
 graph export figureA9.pdf , replace
 
twoway rcap  diffhi difflo outcome if mech==0 & group==1, horiz ylab(1/9, val angle(0) labsize(small)) ///
   legend(label(1 "MPs") /* label(2 "Mass") */ order(1)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
    title("Differences in means: Current MPs") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA10.gph , replace 
 graph export figureA10.pdf , replace
 restore
 
 
 *** FIGURE A11 & A12
 preserve
 gen leader = 0 if position == "BACKBENCHER"
replace leader = 1 if position != "BACKBENCHER" & position != ""
 local k = 0

local vars "coor_peers rally_locals tell_constits enum_pres  pres_sign enum_petition sign_pet tell_support strong_supp"

forval j = 1/`: word count `vars'' {
forval i = 0/1 {
ttest `: word `j' of `vars'' if leader == `i' & mp==1, by(treat_control) unequal
replace outcome = `j' if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 1 if _n==`j'+`i'+`k'
}
local k = `k'+2
}

label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==1, horiz ylab(1/9 , val angle(0) labsize(small)) ///
   legend(label(1 "MPs") /*label(1 "Mass") */ order(1 )) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: Parliamentary Leaders") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA11.gph , replace
 graph export figureA11.pdf , replace

 
twoway rcap  diffhi difflo outcome if mech==0 & group==1, horiz ylab(1/9, val angle(0) labsize(small)) ///
   legend(label(1 "MPs") /* label(2 "Mass") */ order(1)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==1, mcolor(navy)  xline(0, lcolor(black)) ///
    title("Differences in means: Backbencher MPs") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA12.gph , replace
 graph export figureA12.pdf , replace
 restore


 *** FIGURE A13 & A14
 
 preserve
keep if mass == 1

*must make 30,000 Ush per week to pay taxes
gen pay_tax = 0 if income != . | alt_income != .
replace pay_tax = 1 if income >= 30000 & income != . 
replace pay_tax = 1 if alt_income >= 30000 & alt_income != . 

*the 75th percentil is 10 years of schooling
gen high_edu = 0 if education < 10
replace high_edu = 1 if education >= 10

*urban
gen urban_high = 0 if enum_rural == 1
replace urban_high = 1 if enum_rural == 0

*informed: those who said 5 or 6 to at least one of the news source questions
* meaning they look at one media source at least a couple times a week

gen informed_high = 0
replace informed_high = 1 if knowledge_tv == 5 | knowledge_tv == 6
replace informed_high = 1 if knowledge_radio == 5 | knowledge_radio == 6
replace informed_high = 1 if knowledge_newspaper == 5 | knowledge_newspaper == 6
replace informed_high = 1 if knowledge_internet == 5 | knowledge_internet == 6


gen high_types = 0 if pay_tax == 0 | high_edu == 0 | urban_high == 0 | informed_high == 0
replace high_types = 1 if pay_tax == 1 & high_edu == 1 & urban_high == 1 & informed_high == 1


local k = 0
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if high_types==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}


label val outcome outc2
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(11/16 , val angle(0) labsize(small)) ///
   legend(label(1 "Masses") /*label(1 "Mass") */ order(1 )) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: High Types") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA13.gph , replace
 graph export figureA13.pdf , replace
 
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   legend(label(1 "Masses") /* label(2 "Mass") */ order(1)) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
    title("Differences in means: Low Types") note("Pos. difference = treatment>control; neg. difference = control>treatment")
graph save figureA14.gph , replace
graph export figureA14.pdf , replace
 restore
 
 
 *********************
 *Figure A15
 

**MPs who prefer government, treatment vs. control.


gen runyan = 1 if ethnicity == 20
replace runyan = 0 if ethnicity != 20 & ethnicity > 0 & ethnicity != .

egen posview = rowtotal(q71 q72 q73 q74)
replace posview = . if q71==. & q72==. & q73==. & q74==.
tab posview if expand_dup==1  & mp==1
tab posview if mp==1

gen varname = ""
local k = 1
foreach v of varlist strong_support tell_support sign_pet enum_petition pres_sign enum_pres tell_constits rally_locals coor_peers {
replace varname= "`v'"  if _n==`k'
local k = `k'+1

}


  forval i = 70/74 {
  
  gen b`i' = .
  gen hi`i'=.
  gen lo`i'=.
  
reg strong_support ib0.aid_control#ib0.q`i'  nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */ if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==1
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==1
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==1

reg tell_support ib0.aid_control#ib0.q`i'  nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1 
replace b`i' = _b[1.aid_control#0.q`i'] if _n==2
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==2
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==2



reg sign_pet ib0.aid_control#ib0.q`i'  nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==3
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==3
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==3



reg enum_petition ib0.aid_control#ib0.q`i'  nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==4
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==4
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==4


reg pres_sign ib0.aid_control#ib0.q`i'  nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==5
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==5
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==5


reg enum_pres ib0.aid_control#ib0.q`i' nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */ if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==6
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==6
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==6


reg tell_constits ib0.aid_control#ib0.q`i' nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==7
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==7
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==7



reg rally_locals ib0.aid_control#ib0.q`i' nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==8
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==8
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==8


reg coor_peers ib0.aid_control#ib0.q`i' nrm  male region_east region_west region_north runyan /*years_rep_current ///
former_mp backbencher uas_mp dist_mp income_mp foreign_news_top */  if mp==1
replace b`i' = _b[1.aid_control#0.q`i'] if _n==9
replace hi`i' = _b[1.aid_control#0.q`i']+_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==9
replace lo`i' = _b[1.aid_control#0.q`i']-_se[1.aid_control#1.q`i']*(invttail(e(df_r),.05))  if _n==9

  }
  
gen varid = abs(_n-10) if varname~=""
label define dv 9 "Strong support" 8 "Tell" 7 "Willing to sign" 6 "Signed" 5 "Willing sign Pres." 4 "Sign Pres Pet" ///
  3 "Tell constit." 2 "Rally locals" 1 "Coord peers" , modify
  label val varid dv 
twoway scatter   varid b71 || rcap  hi71 lo71 varid, lcolor(navy) horiz ylabel(1/9,val angle(0) labsize(small)) ytitle("")  /// 
xline(0) legend(off) subtitle("Gov. least waste") name(q71 , replace)

twoway scatter   varid b72 || rcap  hi72 lo72 varid, lcolor(navy) horiz ylabel(1/9,val angle(0) labsize(small)) ytitle("")  /// 
xline(0) legend(off) subtitle("Gov. helps neediest") name(q72 , replace)

twoway scatter   varid b73 || rcap  hi73 lo73 varid, lcolor(navy) horiz ylabel(1/9,val angle(0) labsize(small)) ytitle("")  /// 
xline(0) legend(off) subtitle("Gov. transparent") name(q73 , replace)

twoway scatter   varid b74 || rcap  hi74 lo74 varid, lcolor(navy) horiz ylabel(1/9,val angle(0) labsize(small)) ytitle("")  /// 
xline(0) legend(off) subtitle("Gov. matches need") name(q74 , replace)


graph combine q71 q72 q73 q74 , col(2) note("Difference between respondents who received the control and those who received the treatment" "and who also believed that the government was better for each of the outcomes.", size(vsmall)) 

 graph save "figureA15.gph", replace
graph export "figureA15.pdf" , replace

 
 
 
 
 
 
 
 
 
 
 
 *********************
 
 *** TABLE A7
 *** Who helps neediest
* MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q71==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q71==0, by(treat_control) unequal

ttest tell_support if mp==1 & q71==1, by(treat_control) unequal
ttest tell_support if mp==1 & q71==0, by(treat_control) unequal
ttest sign_pet if mp==1 & q71==1, by(treat_control) unequal
ttest sign_pet if mp==1 & q71==0, by(treat_control) unequal
ttest enum_petition if mp==1 & q71==1, by(treat_control) unequal
ttest enum_petition if mp==1 & q71==0, by(treat_control) unequal
ttest pres_sign if mp==1 & q71==1, by(treat_control) unequal
ttest pres_sign if mp==1 & q71==0, by(treat_control) unequal
ttest enum_pres if mp==1 & q71==1, by(treat_control) unequal
ttest enum_pres if mp==1 & q71==0, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1 & q71==1, by(treat_control) unequal
ttest tell_constits if mp==1 & q71==0, by(treat_control) unequal
ttest rally_locals if mp==1 & q71==1, by(treat_control) unequal
ttest rally_locals if mp==1 & q71==0, by(treat_control) unequal
ttest coor_peers if mp==1 & q71==1, by(treat_control) unequal
ttest coor_peers if mp==1 & q71==0, by(treat_control) unequal
 
 
 *** TABLE A8
  *** Least waste
* MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q72==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q72==0, by(treat_control) unequal

ttest tell_support if mp==1 & q72==1, by(treat_control) unequal
ttest tell_support if mp==1 & q72==0, by(treat_control) unequal
ttest sign_pet if mp==1 & q72==1, by(treat_control) unequal
ttest sign_pet if mp==1 & q72==0, by(treat_control) unequal
ttest enum_petition if mp==1 & q72==1, by(treat_control) unequal
ttest enum_petition if mp==1 & q72==0, by(treat_control) unequal
ttest pres_sign if mp==1 & q72==1, by(treat_control) unequal
ttest pres_sign if mp==1 & q72==0, by(treat_control) unequal
ttest enum_pres if mp==1 & q72==1, by(treat_control) unequal
ttest enum_pres if mp==1 & q72==0, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1 & q72==1, by(treat_control) unequal
ttest tell_constits if mp==1 & q72==0, by(treat_control) unequal
ttest rally_locals if mp==1 & q72==1, by(treat_control) unequal
ttest rally_locals if mp==1 & q72==0, by(treat_control) unequal
ttest coor_peers if mp==1 & q72==1, by(treat_control) unequal
ttest coor_peers if mp==1 & q72==0, by(treat_control) unequal
 
 *** TABLE A9
  *** Transparent
* MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q73==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q73==0, by(treat_control) unequal

ttest tell_support if mp==1 & q73==1, by(treat_control) unequal
ttest tell_support if mp==1 & q73==0, by(treat_control) unequal
ttest sign_pet if mp==1 & q73==1, by(treat_control) unequal
ttest sign_pet if mp==1 & q73==0, by(treat_control) unequal
ttest enum_petition if mp==1 & q73==1, by(treat_control) unequal
ttest enum_petition if mp==1 & q73==0, by(treat_control) unequal
ttest pres_sign if mp==1 & q73==1, by(treat_control) unequal
ttest pres_sign if mp==1 & q73==0, by(treat_control) unequal
ttest enum_pres if mp==1 & q73==1, by(treat_control) unequal
ttest enum_pres if mp==1 & q73==0, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1 & q73==1, by(treat_control) unequal
ttest tell_constits if mp==1 & q73==0, by(treat_control) unequal
ttest rally_locals if mp==1 & q73==1, by(treat_control) unequal
ttest rally_locals if mp==1 & q73==0, by(treat_control) unequal
ttest coor_peers if mp==1 & q73==1, by(treat_control) unequal
ttest coor_peers if mp==1 & q73==0, by(treat_control) unequal
 
 *** TABLE A10
 
  *** who matches need
* MPs
*ttest exp if mp==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q74==1, by(treat_control) unequal
ttest strong_supp if mp==1 & q74==0, by(treat_control) unequal

ttest tell_support if mp==1 & q74==1, by(treat_control) unequal
ttest tell_support if mp==1 & q74==0, by(treat_control) unequal
ttest sign_pet if mp==1 & q74==1, by(treat_control) unequal
ttest sign_pet if mp==1 & q74==0, by(treat_control) unequal
ttest enum_petition if mp==1 & q74==1, by(treat_control) unequal
ttest enum_petition if mp==1 & q74==0, by(treat_control) unequal
ttest pres_sign if mp==1 & q74==1, by(treat_control) unequal
ttest pres_sign if mp==1 & q74==0, by(treat_control) unequal
ttest enum_pres if mp==1 & q74==1, by(treat_control) unequal
ttest enum_pres if mp==1 & q74==0, by(treat_control) unequal

*Panel B
*MPs
ttest tell_constits if mp==1 & q74==1, by(treat_control) unequal
ttest tell_constits if mp==1 & q74==0, by(treat_control) unequal
ttest rally_locals if mp==1 & q74==1, by(treat_control) unequal
ttest rally_locals if mp==1 & q74==0, by(treat_control) unequal
ttest coor_peers if mp==1 & q74==1, by(treat_control) unequal
ttest coor_peers if mp==1 & q74==0, by(treat_control) unequal
 
 
 
 
  *** FIGURE A16 & A17
 
 *** TAXES
 preserve
 gen notax= income<=30000 | income==.

local k = 0


local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if notax==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}

label val outcome outc2

twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   legend(label(1 "Mass")  order(1 )) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: Pays tax") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 graph save figureA17.gph , replace
 graph export figureA17.pdf , replace
 
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   legend( label(1 "Mass")  order(1 )) ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Differences in means: No tax") note("Pos. difference = treatment>control; neg. difference = control>treatment")
 
 graph save figureA16.gph , replace
 graph export figureA16.pdf , replace
 

 restore 
 
 
 *** TABLE A11
 *** trust_us trust_wb trust_undp trust_adb
 gen massmp = cond(mass==1, 0,cond(mp==1,1,.))
 ttest trust_usaid , by(massmp) unequal
  ttest trust_wb , by(massmp) unequal
  ttest trust_undp , by(massmp) unequal
   ttest trust_adb , by(massmp) unequal

 
 *** TABLE A12
 gen condhelp = cond(aid_conditionality> 3 & aid_conditionality ~= . ,1,cond(aid_conditionality<3,0,.))
 ttest aid_conditionality , by(massmp) unequal
  ttest condhelp , by(massmp) unequal

  ttest aid_conditionality if treat_control==1, by(massmp) unequal
   ttest condhelp  if treat_control==1, by(massmp) unequal


 
 *** FIGURE A18
  
preserve
keep if manip_donor==1
local k = 0

local k = `k'+10
local varsm "sms sms_willing enum_petition sign_pet tell_support  strong_supp"
forval j = 1/`: word count `varsm'' {
forval i = 0/1 {
local opt ""
if "`: word `j' of `varsm''"=="sms" | "`: word `j' of `varsm''"=="sms_willing" {
local opt "& have_phone==1"
} 

ttest  `: word `j' of `varsm'' if agree_corr==`i' & mass==1 `opt', by(treat_control) unequal
replace outcome = `j'+10 if _n==`j'+`i'+`k'
replace diff = `r(mu_1)'-`r(mu_2)' if _n==`j'+`i'+`k'
replace diffhi = diff + (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace difflo = diff - (invttail(r(df_t),.025))*r(se) if _n==`j'+`i'+`k'
replace mech = `i' if _n==`j'+`i'+`k'
replace group = 2 if _n==`j'+`i'+`k'

}
local k = `k'+2
}


label val outcome outc2

twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(,nolabels) ///
    xtitle("Difference in means") legend(off) ytitle("") ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Corruption/clientelism") name(client1, replace)
   
twoway rcap  diffhi difflo outcome if mech==1 & group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   legend(off) /*legend(label(1 "Mass")  order(1))*/ ytitle("") xtitle("Difference in means")  ///
   || scatter outcome diff if mech==1 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("Corruption/clientelism") name(corr_leg, replace) nodraw xtitle("") title("")  xscale(off) yscale(off)

_gm_edit .corr_leg.plotregion1.draw_view.set_false
_gm_edit .corr_leg.ystretch.set fixed
 
twoway rcap  diffhi difflo outcome if mech==0 & group==2, horiz ylab(11/16, val angle(0) labsize(small)) ///
   /*legend(label(1 "Mass")  order(1))*/ legend(off)   ytitle("") xtitle("Difference in means") ///
   || scatter outcome diff if mech==0 & group==2, mcolor(navy)  xline(0, lcolor(black)) ///
   title("No corruption/clientelism")   name(client0, replace)

gr combine client0 client1, title("Mass respondents passing manipulation check") name(c, replace)
gr combine c corr_leg, cols(1) note("Pos. difference = treatment>control; neg. difference = control>treatment", size(vsmall))

 graph save figureA18.gph , replace
 graph export figureA18.pdf , replace
 
 restore
 *** TABLE A13a & A13b
 tab2 agree_corr nrm if mass==1 , col
 corr agree_corr nrm
  tab2 client_allies nrm if mp==1 , col
corr client_allies nrm
 
 *** TABLE A14
 
 gen minister = inlist(position,"CABINET MINISTER","STATE MINISTER","DEPUTY SPEAKER")
 gen committee= inlist(position,"COMMITTEE VICE CHAIRPERSON","COMMITTEE CHAIRPERSON")
 logit agree_corr education rel_pov knowledge male nrm i.region if mass==1
est store taba14_1
 logit agree_corr  foreignmedia runyankole nationalist  nrm i.region if mass==1
est store taba14_2
 logit agree_corr education   rel_pov knowledge male foreignmedia runyankole nationalist nrm i.region if mass==1
 est store taba14_3
 
logit client_allies  foreignmedia nrm runyankole nationalist if mp==1 & expand_dup==1 , 
est store taba14_4
logit client_allies male foreignmedia nrm runyankole nationalist if mp==1 & expand_dup==1 
est store taba14_5
 logit client_allies male foreignmedia nrm runyankole nationalist minister committee if mp==1 & expand_dup==1 
est store taba14_6
 
 estout taba14_1 taba14_2 taba14_3 taba14_4 taba14_5 taba14_6 using "taba14.txt"  , ///
  replace order(education   rel_pov knowledge male foreignmedia nrm  runyankole nationalist2 minister committee ) stats(N p_d, fmt(%9.0f %9.3f )) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)) ) starlevels(* .1 ** .05 *** .01) 

 
 
 *** TABLE A15
 
*no corruption  
logit sign_pet aid_control nrm  male region_west region_east region_north ///
foreign_news_top if client_allies == 0, cluster(sbjnum)
eststo corr1
logit sign_pet aid_control nrm  male region_west region_east region_north ///
foreign_news_top backbencher uas_mp if client_allies == 0, cluster(sbjnum)
eststo corr2
  
logit pres_sign aid_control nrm  male region_west region_east region_north ///
foreign_news_top if client_allies == 0, cluster(sbjnum)
eststo corr3
logit pres_sign aid_control nrm  male region_west region_east region_north ///
foreign_news_top backbencher uas_mp if client_allies == 0, cluster(sbjnum)
eststo corr4

*yes corruption
logit sign_pet aid_control nrm  male region_west region_east region_north ///
foreign_news_top if client_allies == 1, cluster(sbjnum)
eststo corr5
logit sign_pet aid_control nrm  male region_west region_east region_north ///
foreign_news_top backbencher uas_mp if client_allies == 1, cluster(sbjnum)
eststo corr6
  
logit pres_sign aid_control nrm  male region_west region_east region_north ///
foreign_news_top if client_allies == 1, cluster(sbjnum)
eststo corr7
logit pres_sign aid_control nrm  male region_west region_east region_north ///
foreign_news_top backbencher uas_mp if client_allies == 1, cluster(sbjnum)
eststo corr8

estout corr1 corr2 corr3 corr4 corr5 corr6 corr7 corr8 using "taba15.txt"  , ///
  replace stats(N p_d, fmt(%9.0f %9.3f )) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)) ) starlevels(* .1 ** .05 *** .01) 

 *** TABLE A16
 
*no corruption
logit strong_support aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 0  & mass==1 , cluster(district)
eststo corr1
logit tell_support aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 0  & mass==1 , cluster(district)
eststo corr2
logit enum_petition aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 0 & mass==1 , cluster(district)
eststo corr3
logit sms_willing aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 0 & mass==1 , cluster(district)
eststo corr4
logit sms aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 0 & mass==1 , cluster(district)
eststo corr5

 *yes corruption
logit strong_support aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 1 & mass==1 , cluster(district)
eststo corr6
logit tell_support aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 1 & mass==1 , cluster(district)
eststo corr7
logit enum_petition aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 1 & mass==1 , cluster(district)
eststo corr8
logit sms_willing aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 1 & mass==1 , cluster(district)
eststo corr9
logit sms aid_control nrm  education  knowledge rel_pov  male enum_rural region_west region_east region_north if agree_corr == 1 & mass==1 , cluster(district)
eststo corr10

estout corr1 corr2 corr3 corr4 corr5 corr6 corr7 corr8 corr9 corr10 using "taba16.txt"  , ///
  replace stats(N p_d, fmt(%9.0f %9.3f )) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f)) ) starlevels(* .1 ** .05 *** .01) 


 *** FIGURE A19
 
 *gen strong_supp = cond(exp==4,1,cond(exp==3|exp==2|exp==1,0,.))
gen id = _n
label define id 1 "Foreign" 2 "Control" 3 "Gov (calc.)", replace
label val id id


*** STRONG SUPPORT

sum strong_supp if treat_control==1 & mass==1
local fm = r(mean)
local sd = r(sd)
ci means strong_supp if mass==1 & treat_control==2
local cse = r(se)
local cmean = r(mean)
local N = r(N)
local govmean = (`cmean' -(1-.52)*`fm')/.52
local s2 = ((2*`cse' - `sd'/(sqrt(`N'*.48)))*sqrt(`N'*.52))/sqrt(`N'*.52)
local s21 = sqrt((`cse'^2 - (`sd'^2/`N'*.48)))

gen govmean = `govmean' if _n==3
gen low =`govmean'-1.96*`s21' if _n==3
gen high =`govmean'+1.96*`s21' if _n==3
replace govmean = `cmean' if _n==2
replace low = `cmean'-1.96*`cse' if _n==2
replace high = `cmean'+1.96*`cse' if _n==2

ci means strong_supp if treat_control==1 & mass==1 , 
replace govmean = `r(mean)' if _n==1
replace low = `r(mean)'-1.96*`r(se)' if _n==1
replace high = `r(mean)'+1.96*`r(se)' if _n==1

 
sum strong_supp if treat_control==1 & mp==1 /*& expand_dup==1*/
local fm = r(mean)
local sd = r(sd)
ci means strong_supp if mp==1 & treat_control==2  /*& expand_dup==1*/
local cse = r(se)
local cmean = r(mean)
local N = r(N)
local govmean = (`cmean' -(1-.52)*`fm')/.52
local s2 = ((2*`cse' - `sd'/(sqrt(`N'*.48)))*sqrt(`N'*.52))/sqrt(`N'*.52)
local s21 = sqrt((`cse'^2 - (`sd'^2/`N'*.48)))

gen govmean_mp = `govmean' if _n==3
gen low_mp =`govmean'-1.96*`s21' if _n==3
gen high_mp =`govmean'+1.96*`s21' if _n==3
replace govmean_mp = `cmean' if _n==2
replace low_mp = `cmean'-1.96*`cse' if _n==2
replace high_mp = `cmean'+1.96*`cse' if _n==2

ci means strong_supp if treat_control==1 & mp==1 /* & expand_dup==1*/
replace govmean_mp = `r(mean)' if _n==1
replace low_mp = `r(mean)'-1.96*`r(se)' if _n==1
replace high_mp = `r(mean)'+1.96*`r(se)' if _n==1

 gen id_mp = id+.2
 twoway rcap low high id if id<4 , xlabel(1/3,val) || rcap low_mp high_mp id_mp if id_mp<4 || ///
scatter govmean id if id<4 || scatter govmean_mp id_mp if id<4 ///
 , title("% Strongly Supporting project by treatment") legend(label(3 "Mass") label(4 "MP") order(3 4)) xtitle("") graphreg(margin(r+5)) ///
 ytitle("% Supporting") ylabel(.7(.05).95) /*saving(strong_supp_both.gph, replace)*/ ///
 note("Foreign and control show actual values; gov (calc.) estimates the mean" "for respondents believing control was government", size(small)) 
  graph save figureA19.gph , replace
 graph export figureA19.pdf , replace
 drop govmean-id_mp
 

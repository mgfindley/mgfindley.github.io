

clear

set more off


use "SA Xenophobia replication data.dta"


*y = outcome for the first list experiment, the anger experiment
*treat = treatment condition for the first list experiment; 0 = control, 1 = imm, 2 = ethnic

*y2 = outcome for the second list experiment, the voting experiment
*treat2 = treatment condition for the second list experiment; 0 = control, 1 = imm, 2 = ethnic

/*baseline_y and baseline_2y are the respective control conditions for each experiment
gen baseline_y =.
replace baseline_y = y if treat == 0
gen baseline_y2 =.
replace baseline_y2 = y2 if treat2 == 0
*/


*** balance table ***

*anger 

ttest contact_score if treat < 2, by(treat)
ttest daveyton if treat < 2, by(treat)
ttest no_hs if treat < 2, by(treat)
ttest completed_hs if treat < 2, by(treat)
ttest post_hs if treat < 2, by(treat)
ttest water_private if treat < 2, by(treat)
ttest income_dummy_low if treat < 2, by(treat)
ttest unemployed if treat < 2, by(treat)
ttest ethnic_strength_new if treat < 2, by(treat)
ttest age if treat < 2, by(treat)
ttest male if treat < 2, by(treat)
ttest ethnic_xhosa if treat < 2, by(treat)
ttest ethnic_zulu if treat < 2, by(treat)
ttest ethnic_other if treat < 2, by(treat)
ttest yr2011 if treat < 2, by(treat)

*vote

ttest contact_score if treat2 < 2, by(treat2)
ttest daveyton if treat2 < 2, by(treat2)
ttest no_hs if treat2 < 2, by(treat2)
ttest completed_hs if treat2 < 2, by(treat2)
ttest post_hs if treat2 < 2, by(treat2)
ttest water_private if treat2 < 2, by(treat2)
ttest income_dummy_low if treat2 < 2, by(treat2)
ttest unemployed if treat2 < 2, by(treat2)
ttest ethnic_strength_new if treat2 < 2, by(treat2)
ttest age if treat2 < 2, by(treat2)
ttest male if treat2 < 2, by(treat2)
ttest ethnic_xhosa if treat2 < 2, by(treat2)
ttest ethnic_zulu if treat2 < 2, by(treat2)
ttest ethnic_other if treat2 < 2, by(treat2)
ttest yr2011 if treat2 < 2, by(treat2)


*observed proportions for y values
*list 1 (anger)
tab y if treat == 0
tab y if treat == 1
tab y if treat == 2
*list 2 (vote)
tab y2 if treat2 == 0
tab y2 if treat2 == 1




*generate indicators for immigrant treatment outcome for each experiment

gen imm_anger_y = y if treat == 1 
gen imm_vote_y2 = y2 if treat2 == 1 


*** Table 1 ***

*full sample
ttest baseline_y = imm_anger_y, unpaired
ttest baseline_y2 = imm_vote_y2, unpaired

*now each survey one at a time
*2009
ttest baseline_y = imm_anger_y if yr2011 == 0, unpaired
ttest baseline_y2 = imm_vote_y2 if yr2011 == 0, unpaired
*2011
ttest baseline_y = imm_anger_y if yr2011 == 1, unpaired
ttest baseline_y2 = imm_vote_y2 if yr2011 == 1, unpaired

*now compare treatments across the surveys as a way to test the effect of the world cup

gen imm_anger_y_09 = imm_anger_y if yr2011 == 0
gen imm_anger_y_11 = imm_anger_y if yr2011 == 1

gen imm_vote_y2_09 = imm_vote_y2 if yr2011 == 0
gen imm_vote_y2_11 = imm_vote_y2 if yr2011 == 1


*differences across locales?
ttest baseline_y = imm_anger_y if daveyton == 1, unpaired
ttest baseline_y2 = imm_vote_y2 if daveyton == 1, unpaired

ttest baseline_y = imm_anger_y if mdantsane == 1, unpaired
ttest baseline_y2 = imm_vote_y2 if mdantsane == 1, unpaired

ttest baseline_y2 = imm_vote_y2 if mdantsane == 0 & daveyton == 0, unpaired
ttest baseline_y = imm_anger_y if mdantsane == 0 & daveyton == 0, unpaired



*y frequencies
*observed proportions for y values
*list 1 (anger)
tab y if treat == 0
tab y if treat == 1
tab y if treat == 2

*observed proportions for y values
*list 2 (vote)
tab y if treat == 0
tab y if treat == 1
tab y if treat == 2


*2009 and 2011 data compared


ttest contact_score, by(yr2011)
ttest no_hs, by(yr2011)
ttest completed_hs, by(yr2011)
ttest post_hs, by(yr2011)
ttest water_private, by(yr2011)
ttest income_dummy_low, by(yr2011)
ttest unemployed, by(yr2011)
ttest ethnic_strength_new, by(yr2011)
ttest age, by(yr2011)
ttest male, by(yr2011)
ttest ethnic_xhosa, by(yr2011)
ttest ethnic_zulu, by(yr2011)
ttest ethnic_other, by(yr2011)
ttest y, by(yr2011)
ttest y2, by(yr2011)

*daveyton only
ttest contact_score if daveyton == 1, by(yr2011)
ttest no_hs if daveyton == 1, by(yr2011)
ttest completed_hs if daveyton == 1, by(yr2011)
ttest post_hs if daveyton == 1, by(yr2011)
ttest water_private if daveyton == 1, by(yr2011)
ttest income_dummy_low if daveyton == 1, by(yr2011)
ttest unemployed if daveyton == 1, by(yr2011)
ttest ethnic_strength_new if daveyton == 1, by(yr2011)
ttest age if daveyton == 1, by(yr2011)
ttest male if daveyton == 1, by(yr2011)
ttest ethnic_xhosa if daveyton == 1, by(yr2011)
ttest ethnic_zulu if daveyton == 1, by(yr2011)
ttest ethnic_other if daveyton == 1, by(yr2011)
ttest y if daveyton == 1, by(yr2011)
ttest y2 if daveyton == 1, by(yr2011)


*** Table 2 ***

*Difference of means tests

*contact
*anger imm conditions
ttest contact_y_t20_base = contact_y_imm_t20, unpaired
ttest contact_y_b20_base = contact_y_imm_b20, unpaired
*vote imm conditions
ttest contact_y2_t20_base = contact_y2_imm_t20, unpaired
ttest contact_y2_b20_base = contact_y2_imm_b20, unpaired



*tri education coding
*anger imm conditions
ttest edu_tri_y_no_hs_base = edu_tri_y_imm_no_hs, unpaired
ttest edu_tri_y_hs_base = edu_tri_y_imm_hs, unpaired
ttest edu_tri_y_hs_plus_base = edu_tri_y_imm_hs_plus, unpaired

*vote imm conditions

gen edu_tri_y2_no_hs_base = .
replace edu_tri_y2_no_hs_base = baseline_y2 if (schooling == 1 | schooling == 2 | schooling == 3 | schooling == 4)
gen edu_tri_y2_hs_base = .
replace edu_tri_y2_hs_base = baseline_y2 if (schooling == 5)
gen edu_tri_y2_hs_plus_base = .
replace edu_tri_y2_hs_plus_base = baseline_y2 if (schooling == 6 | schooling == 7)

gen edu_tri_y2_imm_no_hs =.
replace edu_tri_y2_imm_no_hs = y2 if treat2 == 1 & (schooling == 1 | schooling == 2 | schooling == 3 | schooling == 4)
gen edu_tri_y2_imm_hs =.
replace edu_tri_y2_imm_hs = y2 if treat2 == 1 & (schooling == 5)
gen edu_tri_y2_imm_hs_plus =.
replace edu_tri_y2_imm_hs_plus = y2 if treat2 == 1 & (schooling == 6 | schooling == 7)

ttest edu_tri_y2_no_hs_base = edu_tri_y2_imm_no_hs, unpaired
ttest edu_tri_y2_hs_base = edu_tri_y2_imm_hs, unpaired
ttest edu_tri_y2_hs_plus_base = edu_tri_y2_imm_hs_plus, unpaired


*water
*anger immigrant conditions
ttest y_water_private_base = water_y_private_imm, unpaired
ttest y_water_public_base = water_y_public_imm, unpaired

*vote imm conditions

gen y2_water_private_base = .
replace y2_water_private_base = baseline_y2 if water_private == 1
gen y2_water_public_base = .
replace y2_water_public_base = baseline_y2 if water_private == 0

gen water_y2_private_imm =.
replace water_y2_private_imm = y2 if treat2 == 1 & water_private == 1
gen water_y2_public_imm =.
replace water_y2_public_imm = y2 if treat2 == 1 & water_private == 0

ttest y2_water_private_base = water_y2_private_imm, unpaired
ttest y2_water_public_base = water_y2_public_imm, unpaired



*ethnic strength
*anger imm conditions
ttest strength_y_t20_base = strength_y_imm_t20, unpaired
ttest strength_y_b20_base = strength_y_imm_b20, unpaired

*vote imm conditions

gen strength_y2_t20_base = .
replace strength_y2_t20_base = baseline_y2 if ethnic_strength_new > 3.61
gen strength_y2_b20_base = .
replace strength_y2_b20_base = baseline_y2 if ethnic_strength_new < 2.93

gen strength_y2_imm_t20 =.
replace strength_y2_imm_t20 = y2 if treat2 == 1 & ethnic_strength_new > 3.61
gen strength_y2_imm_b20 =.
replace strength_y2_imm_b20 = y2 if treat2 == 1 & ethnic_strength_new < 2.93

ttest strength_y2_t20_base = strength_y2_imm_t20, unpaired
ttest strength_y2_b20_base = strength_y2_imm_b20, unpaired


*employment

gen y_unemployed_base = .
replace y_unemployed_base = baseline_y if unemployed == 1
gen y_employed_base = .
replace y_employed_base = baseline_y if unemployed == 0

gen y_unemployed_imm =.
replace y_unemployed_imm = y if treat == 1 & unemployed == 1
gen y_employed_imm =.
replace y_employed_imm = y if treat == 1 & unemployed == 0

gen y2_unemployed_base = .
replace y2_unemployed_base = baseline_y2 if unemployed == 1
gen y2_employed_base = .
replace y2_employed_base = baseline_y2 if unemployed == 0

gen y2_unemployed_imm =.
replace y2_unemployed_imm = y2 if treat2 == 1 & unemployed == 1
gen y2_employed_imm =.
replace y2_employed_imm = y2 if treat2 == 1 & unemployed == 0

*anger imm
ttest y_unemployed_base = y_unemployed_imm, unpaired
ttest y_employed_base = y_employed_imm, unpaired
*vote imm
ttest y2_unemployed_base = y2_unemployed_imm, unpaired
ttest y2_employed_base = y2_employed_imm, unpaired


*anger imm
*2009
ttest y_unemployed_base = y_unemployed_imm if year == 2009, unpaired
ttest y_employed_base = y_employed_imm if year == 2009, unpaired
*2011
ttest y_unemployed_base = y_unemployed_imm if year == 2011, unpaired
ttest y_employed_base = y_employed_imm if year == 2011, unpaired

*vote imm
*2009
ttest y2_unemployed_base = y2_unemployed_imm if year == 2009, unpaired
ttest y2_employed_base = y2_employed_imm if year == 2009, unpaired
*2011
ttest y2_unemployed_base = y2_unemployed_imm if year == 2011, unpaired
ttest y2_employed_base = y2_employed_imm if year == 2011, unpaired

*only on daveyton
*anger
ttest y_unemployed_base = y_unemployed_imm if daveyton == 1, unpaired
ttest y_employed_base = y_employed_imm if daveyton == 1, unpaired
*vote
ttest y2_unemployed_base = y2_unemployed_imm if daveyton == 1, unpaired
ttest y2_employed_base = y2_employed_imm if daveyton == 1, unpaired

*only Mdan/Umlazi
*anger
ttest y_unemployed_base = y_unemployed_imm if daveyton == 0, unpaired
ttest y_employed_base = y_employed_imm if daveyton == 0, unpaired
*vote
ttest y2_unemployed_base = y2_unemployed_imm if daveyton == 0, unpaired
ttest y2_employed_base = y2_employed_imm if daveyton == 0, unpaired

* Mdantsane alone
*anger
ttest y_unemployed_base = y_unemployed_imm if mdantsane == 1, unpaired
ttest y_employed_base = y_employed_imm if mdantsane == 1, unpaired

* umlazi alone
*anger
ttest y_unemployed_base = y_unemployed_imm if daveyton == 0 & mdantsane == 0, unpaired
ttest y_employed_base = y_employed_imm if daveyton == 0 & mdantsane == 0, unpaired




*income

gen y_inc_low_base = .
replace y_inc_low_base = baseline_y if income_dummy_low == 1
gen y_inc_hi_base = .
replace y_inc_hi_base = baseline_y if income_dummy_low == 0

gen y_inc_low_imm =.
replace y_inc_low_imm = y if treat == 1 & income_dummy_low == 1
gen y_inc_hi_imm =.
replace y_inc_hi_imm = y if treat == 1 & income_dummy_low == 0

gen y2_inc_low_base = .
replace y2_inc_low_base = baseline_y2 if income_dummy_low == 1
gen y2_inc_hi_base = .
replace y2_inc_hi_base = baseline_y2 if income_dummy_low == 0

gen y2_inc_low_imm =.
replace y2_inc_low_imm = y2 if treat2 == 1 & income_dummy_low == 1
gen y2_inc_hi_imm =.
replace y2_inc_hi_imm = y2 if treat2 == 1 & income_dummy_low == 0

*anger imm
ttest y_inc_low_base = y_inc_low_imm, unpaired
ttest y_inc_hi_base = y_inc_hi_imm, unpaired
*vote imm
ttest y2_inc_low_base = y2_inc_low_imm, unpaired
ttest y2_inc_hi_base = y2_inc_hi_imm, unpaired



*chow test
*can accept the null of no structural change

chowreg y schooling water_private income_dummy_low unemployed contact_score dist_avg_rescale daveyton ethnic_strength_new age male ethnic_xhosa ethnic_other yr2011 if treat == 1, dum(208)
chowreg y schooling water_private income_dummy_low unemployed contact_score dist_avg_rescale daveyton ethnic_strength_new age male ethnic_xhosa ethnic_other yr2011 if treat == 0, dum(191)

chowreg y2 schooling water_private income_dummy_low unemployed contact_score dist_avg_rescale daveyton ethnic_strength_new age male ethnic_xhosa ethnic_other yr2011 if treat2 == 1, dum(210)
chowreg y2 schooling water_private income_dummy_low unemployed contact_score dist_avg_rescale daveyton ethnic_strength_new age male ethnic_xhosa ethnic_other yr2011 if treat2 == 0, dum(199)









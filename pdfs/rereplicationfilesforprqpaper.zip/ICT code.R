


#Summary: with new variables, edu findings from previous are robust and I find a positive relationship between unemployment and immigrant prejudice, these results are robust to ceiling effects
#Can’t do ceiling effects with contact and distance interaction so I opted to not include it in the analysis
#Also, results are robust to adding income and to replacing water_private with income
#Final Commands for R ICT Analysis

library(foreign)
library(list)

lists.trans <- read.dta ("Complete Data Set with List Categories.dta")

#Prejudice model: treat = 0 1 (not 0 1 2)
#lists.trans <- read.dta ("C:/Users/Adam/Dropbox/NYU/2011 Summer/SA 2011 Household Survey/Data Analysis/ Data for R treat 0 1.dta") DOESN’T WORK
#Only 2009
#lists.trans <- read.dta ("C:/Users/Adam/Dropbox/NYU/2011 Summer/SA 2011 Household Survey/Data Analysis/Complete Data 2009.dta")
#Only2011
#lists.trans <- read.dta ("C:/Users/Adam/Dropbox/NYU/2011 Summer/SA 2011 Household Survey/Data Analysis/Complete Data 2011.dta")

lists.one <- subset(lists.trans, treat == 1 | treat == 0)
lists.two <- subset(lists.trans, treat == 2 | treat == 0)
lists.two$treat <- lists.two$treat > 0

lists.one.vote <- subset(lists.trans, treat2 == 1 | treat2 == 0)

#design effects 1.1
proportions <- ict.test(lists.one$y, lists.one$treat, J = 4, gms = TRUE)
proportions
#NONE!
proportions5 <- ict.test(lists.one$y, lists.one$treat, J = 5, gms = TRUE)
proportions5
#this second one gives results for saying yes to all 5 tiems in the treatment

#Design effects 1.2
proportions <- ict.test(lists.two$y, lists.two$treat, J =4, gms = TRUE)
proportions
#NONE!
proportions5 <- ict.test(lists.two$y, lists.two$treat, J =5 , gms = TRUE)
proportions5

#Design effects vote experiment, immigrant treatment
proportions_v <- ict.test(lists.one.vote$y, lists.one.vote$treat2, J = 4, gms = TRUE)
proportions_v
#NONE!
proportions5_v <- ict.test(lists.one.vote$y, lists.one.vote$treat2, J = 5, gms = TRUE)
proportions5_v



Model
Y = B + contact + daveyton + hs + post hs +water +strength + age + male +xhosa + other ethnic + yr2011

#MODELS reported in draft as of March 31st 2014
#1.1 with tri_dummies for edu ADD LOW_INCOME DUMMY, UNEMPLOYED DUMMY, AND DISTANCE AND CONTACT_DISTANCE INTERACTION (AVERAGE DISTANCE), with or without the itnereaction, unemployment is sig at the .05 level
results1.1 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa  + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale, data = lists.one, J = 4)
results1.2 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa  + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale, data = lists.two, J = 4)


#now for the voting experiment:

lists <- read.dta ("/Users/adamharris/Dropbox/NYU/2011/2011 2-Summer/MA Paper Final/Data/Complete Data Set with List Categories list 2 cond 1.dta")

#I had to do lm as the model type here or else I couldnt' get results ... some werid error
vote.list <- subset(lists.trans, treat2 == 1 | treat2 == 0)
#no significant results for unemployment
results.vote.exp <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa  + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale, data = vote.list, method = "lm", treat = "treat2", J = 4)

summary(results.vote.exp)
#Treatment
df <- length(vote.list$y) - 15
t <- results.vote.exp$par.treat/results.vote.exp$se.treat
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display
#95% CI Treatment
ci.ub.tr <- results.vote.exp$par.treat + (results.vote.exp$se.treat*1.96)
ci.ub.tr
ci.lb.tr <- results.vote.exp$par.treat - (results.vote.exp$se.treat*1.96)
ci.lb.tr

#Control
t <- results.vote.exp$par.control/results.vote.exp$se.control
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display
#95% CI Control
ci.ub.cl <- results.vote.exp$par.control + (results.vote.exp$se.control*1.96)
ci.ub.cl
ci.lb.cl <- results.vote.exp$par.control - (results.vote.exp$se.control*1.96)
ci.lb.cl













#nothing significant
#for 2009: completed hs* neg

#1.1 WITH ceiling and floor effects ADD LOW_INCOME DUMMY, UNEMPLOYED DUMMY, AND DISTANCE AND CONTACT_DISTANCE INTERACTION (AVERAGE DISTANCE)
results1.1 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011  + income_dummy_low + unemployed + dist_avg_rescale, data = lists.one, J = 4, ceiling = T, ceiling.fit = "bayesglm", floor = T, floor.fit = "bayesglm", ceiling.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011, floor.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011  + income_dummy_low + unemployed + dist_avg_rescale)
*still nothing significant
*doesn’t work

1.1 ceiling with new variables but not the distance contact interaction, unemployment results are robust
#MODEL IN PAPER; at least that's what it says, but I can't this one to work running it on 24 march 2012
results1.1.c <- ictreg(lists.one$y ~ lists.one$contact_score + lists.one$daveyton + lists.one$completed_hs + lists.one$post_hs + lists.one$water_private + lists.one$ethnic_strength_new + lists.one$age10 + lists.one$male + lists.one$ethnic_xhosa + lists.one$ethnic_other + lists.one$yr2011  + lists.one$income_dummy_low + lists.one$unemployed + lists.one$dist_avg_rescale, data = lists.one, J = 4, ceiling = T, ceiling.fit = "bayesglm", ceiling.formula = ~ lists.one$contact_score + lists.one$daveyton + lists.one$completed_hs + lists.one$post_hs + lists.one$water_private + lists.one$ethnic_strength_new + lists.one$age10 + lists.one$male + lists.one$ethnic_xhosa + lists.one$ethnic_other + lists.one$yr2011 + lists.one$income_dummy_low + lists.one$unemployed + lists.one$dist_avg_rescale)
*still nothing significant
#now as a linear model: exact same results, so using the lm method for lists 2 and 3 will be comparable, from what I can tell
results1.1.c <- ictreg(lists.one$y ~ lists.one$contact_score + lists.one$daveyton + lists.one$completed_hs + lists.one$post_hs + lists.one$water_private + lists.one$ethnic_strength_new + lists.one$age10 + lists.one$male + lists.one$ethnic_xhosa + lists.one$ethnic_other + lists.one$yr2011  + lists.one$income_dummy_low + lists.one$unemployed + lists.one$dist_avg_rescale, data = lists.one, J = 4, ceiling = T, ceiling.fit = "bayesglm", ceiling.formula = ~ lists.one$contact_score + lists.one$daveyton + lists.one$completed_hs + lists.one$post_hs + lists.one$water_private + lists.one$ethnic_strength_new + lists.one$age10 + lists.one$male + lists.one$ethnic_xhosa + lists.one$ethnic_other + lists.one$yr2011 + lists.one$income_dummy_low + lists.one$unemployed + lists.one$dist_avg_rescale, method = "lm")

1.1 floor
results1.1 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale + contact_dist_avg, data = lists.one, J = 4, floor = T, floor.fit = "bayesglm", floor.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale + contact_dist_avg)
*not mono increasing

summary(results1.1)
#Treatment
df <- length(lists.one$y) - 15
t <- results1.1$par.treat/results1.1$se.treat
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display
#95% CI Treatment
ci.ub.tr <- results1.1$par.treat + (results1.1$se.treat*1.96)
ci.ub.tr
ci.lb.tr <- results1.1$par.treat - (results1.1$se.treat*1.96)
ci.lb.tr

#Control
t <- results1.1$par.control/results1.1$se.control
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display
#95% CI Control
ci.ub.cl <- results1.1$par.control + (results1.1$se.control*1.96)
ci.ub.cl
ci.lb.cl <- results1.1$par.control - (results1.1$se.control*1.96)
ci.lb.cl


1.2 results are the same with the new variables but not the interaction of distance and contact and is robust to ceiling effects
with the distance and contact interaction, the edu finding is significant at the .05 level but is not robust to ceiling effects because the model won’t converge
results1.2 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa  + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale, data = lists.two, J = 4)
post_hs* is neg
for 2009 data: nothing significant
+ contact_dist_avg

1.2 with ceiling and floor effects
results1.2 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011, data = lists.two, J = 4, ceiling = T, ceiling.fit = "bayesglm", floor = T, floor.fit = "bayesglm", ceiling.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011, floor.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011)
*not mono increasing

1.2 with ceiling, robust without the distance contact interaction
results1.2 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale, data = lists.two, J = 4, ceiling = T, ceiling.fit = "bayesglm", ceiling.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011 + income_dummy_low + unemployed + dist_avg_rescale)
*robust
#odds ratio; for post_hs = 0.3377658
exp(results1.2$par.treat)

1.2 with floor effects
results1.2 <- ictreg(y ~ contact_score + daveyton + completed_hs + post_hs  + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011, data = lists.two, J = 4, floor = T, floor.fit = "bayesglm", floor.formula = ~ contact_score + daveyton + completed_hs + post_hs + water_private + ethnic_strength_new + age10 + male + ethnic_xhosa + ethnic_other + yr2011)
*not mono increasing

summary(results1.2)
#Treatment
df <- length(lists.two$y) - 15
t <- results1.2$par.treat/results1.2$se.treat
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display

#95% CI Treatment
ci.ub.tr <- results1.2$par.treat + (results1.2$se.treat*1.96)
ci.ub.tr
ci.lb.tr <- results1.2$par.treat - (results1.2$se.treat*1.96)
ci.lb.tr

#Control
t <- results1.2$par.control/results1.2$se.control
p <- (1-pt(abs(t),df))*2
display <- cbind(t, p)
display

#95% CI Control
ci.ub.cl <- results1.2$par.control + (results1.2$se.control*1.96)
ci.ub.cl
ci.lb.cl <- results1.2$par.control - (results1.2$se.control*1.96)
ci.lb.cl



version 8.2	/* do-file to generate final covariates and run regressions on Findley Teo dataset */
set more off
clear

use "SET PATH HERE", clear

log using "SET PATH HERE", text replace

/* stset the data with intervention on govt as failure type */
/* time1 is duration variable */
/* origin of analysis time is set to be minimum of time0, which has been offset to zero */
/* failure = 1 for govtinter, neutrality/censoring and oppinter are baselines */
/* exit when records run out for each id */
/* id variable is id */
stset time1, failure(govtinter==1) origin(time time0) time0(time0) exit(time .) id(id)

/* log-normal cure model for govtinter, jointdem, logfatalities and loglforced added */
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum logfatalities loglforced)

/* stset the data with intervention on opp as failure type */
/* time1 is duration variable */
/* origin of analysis time is set to be minimum of time0, which has been offset to zero */
/* failure = 1 for oppinter, neutrality/censoring and govtinter are baselines */
/* exit when records run out for each id */
/* id variable is id */
stset time1, failure(oppinter==1) origin(time time0) time0(time0) exit(time .) id(id)

/* log-normal cure model for oppinter */
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum logfatalities loglforced)


log close
clear

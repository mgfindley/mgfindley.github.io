*********************************************
* Replication Materials                     *
* for Young & Findley 2011, Public Choice   *
* Author: Joseph Young & Michael Findley    *
* Date: 9/1/11                              *
*********************************************

* This do-file directly replicates the models from 
* Joseph K. Young and Michael G. Findley. 2011
* ``Can Peace Be Purchased? A Sectoral-Level Analysis of Aid�s Influence on Transnational Terrorism,''
* Public Choice 149(3/4): 365-381.

*Summary of the results consistent with Tables 1 - 3 in Young/Findley 2011

*****************************************************************
* Model | Tests                  *  Sign * Significant  * Table *
* 1. All Aid /GDP                *   -   *     No       *   1   *
* 2. All Aid /GDP with Fix       *   -   *    Yes       *   1   *  
* 3. Educ. Aid /GDP              *   -   *     No       *   1   *
* 4. Educ. Aid /GDP with Fix     *   -   *    Yes       *   1   *
* 5. Conflict Aid /GDP           *   -   *    Yes       *   2   *
* 6. Conflict Aid /GDP w/Fix     *   -   *    Yes       *   2   *
* 7. Health Aid /GDP             *   -   *    Yes       *   2   * 
* 8. Health Aid /GDP with Fix    *   -   *    Yes       *   2   *       
* 9. Governance Aid /GDP         *   -   *     No       *   3   *
*10. Governance Aid /GDP w/Fix   *   -   *  No (0.111)  *   3   *
*11. Civic Aid /GDP              *   -   *     No       *   3   *
*12. Civic Aid /GDP w/Fix        *   -   *     Yes      *   3   *
*****************************************************************

use  young_findley_pc_2011_repdata.dta

**************************************
*        Model 1, Table 1            *
* DV: Iterate attacks                *
* IV: Bilateral Aid / GDP            *
**************************************

*1. All Aid/GDP
nbreg f.terrorCount smbilataidpergdp  exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


**************************************
*        Model 2, Table 1            *
* Azam Endogeneity Fix               *
* DV: Iterate attacks                *
* IV: Bilateral Aid / GDP            *
**************************************

*2. All Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smbilataidpergdp res_all exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


**************************************
*        Model 3, Table 1            *
*      Test of Azam Model            *
* DV: Iterate attacks                *
* IV: Education Aid / GDP            *
**************************************

*3. Ed. Aid/GDP
nbreg f.terrorCount smedubilaidpergdp smbudgbilaidpergdp exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


*************************************
*       Model 4, Table 1            * 
*      Azam Endogenity Fix          *
* DV: Iterate                       *
* IV: Education Aid / GDP           *
*************************************

*4. Ed. Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smedubilaidpergdp smbudgbilaidpergdp res_ed exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog

 
*************************************
*       Model 5, Table 2            * 
*         Sandler Model             *
* DV: Iterate                       *
* IV: Conflict AID/GDP              *
************************************* 

*5. Conflict Aid/GDP
nbreg f.terrorCount smconfbilaidpergdp smbudgbilaidpergdp exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


*************************************
*       Model 6, Table 2            * 
*      Azam Endogenity Fix          *
*         Sandler Model             *
* DV: Iterate                       *
* IV: Conflict AID/GDP              *
*************************************

*6. Conflict Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smconfbilaidpergdp smbudgbilaidpergdp res_con exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


**************************************
*        Model 7, Table 2            *
* DV: Iterate attacks                *
* IV: Health Aid / GDP               *
**************************************

*7. Health Aid/GDP
nbreg f.terrorCount smhealbilaidpergdp smbudgbilaidpergdp  exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum* , cluster(ccode) nolog


**************************************
*        Model 8, Table 2            *
* Azam Endogeneity Fix               *
* DV: Iterate attacks                *
* IV: Health Aid / GDP               *
**************************************


*8. Health Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smhealbilaidpergdp smbudgbilaidpergdp res_health exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum* , cluster(ccode) nolog


*************************************
*       Model 9, Table 3            * 
*      Governance Bilateral Aid     *
* DV: Iterate                       *
* IV: Governance AID/GDP            *
*************************************

*9. Gov. Aid/GDP
nbreg f.terrorCount smgovernancebilatpergdp smbudgbilaidpergdp exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog


*************************************
*       Model 10, Table 3          * 
*      Governance Bilateral Aid     *
*      Azam Endog. Fix              *
* DV: Iterate                       *
* IV: Governance AID/GDP            *
*************************************

*10. Gov. Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smgovernancebilatpergdp smbudgbilaidpergdp res_gov exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum* , cluster(ccode) nolog


*************************************
*       Model 11, Table 3           * 
*      Civil Bilateral Aid          *
*         				            *
* DV: Iterate                       *
* IV: Civil AID/GDP                 *
*************************************

*11. Civic Aid/GDP
nbreg f.terrorCount smcivilsocbilatpergdp smbudgbilaidpergdp exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog

*************************************
*       Model 12, Table 3           * 
*      Civil Bilateral Aid          *
*      Azam Endog. Fix   	        *
* DV: Iterate                       *
* IV: Governance AID/GDP            *
*************************************

*12. Civil Aid/GDP with Endogeneity Fix
nbreg f.terrorCount smcivilsocbilatpergdp smbudgbilaidpergdp res_civ exconst participation loggdppercapitaconstant2000us logPop  incidencev410 terrorCount5 regiondum*, cluster(ccode) nolog







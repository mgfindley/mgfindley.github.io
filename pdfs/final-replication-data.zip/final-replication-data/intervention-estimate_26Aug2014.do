/*    REPLICATION NOTES  
Date:        		1 May 2014
Code Version:		Final Version
Author:      		Findley and Marineau
Purpose:     		These files reproduce all results reported in tables for CMPS
					"Lootable Resources and Third-Party Intervention in Civil War" (Year XXXX; Vol. XX; Issue XX)
Publications:		Paper: "Causes of Non-Compliance.final.29Mar2014.docx"					
					Append: "Appendix.Causes of Non-Compliance.final.29Mar2014.docx"
Data Used:   		Dataset collected by Regan 2002
File Names:   		"intervention-estimate_1May14.do" (file that estimates the models reported in paper)
Input Files:		"interven-with-fearon-lujala.dta" (Intl data)
					"interven-with-fearon-lujala.dta" (US data)
Output Files: 		"merge\test-lujala.log"
Machine:     		MGF; Macbook
Version:			Stata 13.1
Preregistration:	Research design not preregistered with EGAP (www.e-gap.org); 
Replication:		Materials will be availble at http://michael-findley.com
*/

version 8.2 /* do-file to generate final covariates and run regressions on Findley and Marineau dataset */
clear
set more off

*NOTE: Need to set path to the folder with the data file
*cd "CHANGE FILE PATH HERE"

*log using "merge\test-lujala.log", text replace
use "interven-with-fearon-lujala.dta", clear

///////////////////////////////////////////////////////////////////////////////////////
//	*************************   MAIN PAPER MODELS    ******************************* //
///////////////////////////////////////////////////////////////////////////////////////

/* generate final covariates */

generate contigdum = 0  /* direct geographical contiguity dummy var */
replace contigdum = 1 if contig == 1

generate allydum = 0    /* alliance ties b/w potential intervner and CW country dummy var */
replace allydum = 1 if ally < 4

generate allyongovtdum = 0  /* if ally has already intervened on side of govt dummy var */
replace allyongovtdum = 1 if allyongovt > 0

generate allyonoppdum = 0   /* if ally has already intervened on side of opp dummy var */
replace allyonoppdum = 1 if allyonopp > 0

generate rivalongovtdum = 0 /* if rival has already intervened on side of govt dummy var */
replace rivalongovtdum = 1 if rivalongovt > 0

generate rivalonoppdum = 0  /* if rival has already intervened on side of opp dummy var */
replace rivalonoppdum = 1 if rivalonopp > 0

tabulate oppgroup, generate(oppgroup)   /* type of conflict or main opposition group dummy vars */
rename oppgroup1 religious  /* rename these vars */
rename oppgroup2 ethnic
rename oppgroup3 ideology

generate capratio = thirdcap/cap    /* capability ratio vars */
generate logcapratio = log10(capratio)

generate jointdem = 0   /* joint democracy dummy var */
replace jointdem = 1 if polity>=6 & thirdpolity>=6 & polity~=. & thirdpolity~=.
replace jointdem =. if polity==. & thirdpolity==.

generate logfatalities = log10(fatalities2 + 1) /* base-10 log of Uppsalla/PRIO battledeaths var */

generate loglforced = log10(lforced + 1)    /* base-10 log of Moore/Shellman lforced refugee var */

generate anyresource_C = ALLGEMP_C 	/*creating the gems, diamonds, and drugs dummy variable */
replace anyresource_C = 1 if DRUGS_C == 1
replace anyresource_C = 1 if fearonContraband == 1

gen rivalconf = 0 	/*dummy variable for whether the rival has intervened on the side of the government or opposition */
replace rivalconf = 1 if rivalongovtdum == 1
replace rivalconf = 1 if rivalonoppdum == 1

gen allyconf = 0 /*dummy variable for whether the ally has intervened on the side of the government or opposition */
replace allyconf = 1 if allyongovtdum == 1
replace allyconf = 1 if allyonoppdum == 1

compress

/* keep only vars needed for stset and regressions */
*keep target govtinter oppinter phase rival thirdmajpow time0 time1 id colhist lforced loglforced coldwar fatalities2 logfatalities contigdum allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum religious ethnic ideology sameregion capratio logcapratio jointdem   L_PRODUCTION L_PC_PRODUCTION L_RESERVES L_PC_RESERVES L_DIAMONDS L_PC_DIAMONDS jointLing jointRel jointEth violdissent bothgnp ptssd wbtotpop dem_aut waronter deathmag anocl instab polity2l nwstate muslim ef lmtnest gdpenl lpop  third_educ third_edu_spend third_hinst third_durable third_van_id third_van_part third_van_comp third_polity_stand third_cheibub_stand third_vanhanen_stand third_fh_stand educ edu_spend hinst durable van_id van_part van_comp polity_stand cheibub_stand vanhanen_stand fh_stand fearonContraband  PDIAP_C GEMP_C ALLGEMP_C DRUGS_C oild_C oilp_C gasd_C gasp_C hydrop_C hydrod_C 
keep target govtinter oppinter phase rival thirdmajpow time0 time1 id colhist lforced loglforced coldwar fatalities2 logfatalities contigdum allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum religious ethnic ideology sameregion capratio logcapratio jointdem    SDIAP_C-ALlangLN fearonContraband anyresource rivalconf allyconf relevant

*Generating variable for all gems and drugs
gen gemsdrugs_C = .
replace gemsdrugs_C = 0 if ALLGEMP_C == 0 | DRUGS_C == 0
replace gemsdrugs_C = 1 if ALLGEMP_C == 1 | DRUGS_C == 1

***Generating variable for any intervention
gen anyinter = 0
replace anyinter = 1 if govtinter == 1
replace anyinter = 1 if oppinter == 1

*Dropping duplicates
drop if id ==.
duplicates drop id phase, force

/* save the required vars in a different file first */
save "interven-estimate-test.dta", replace





/******************************* GENERATING HAZARD RATIOS FOR ANY INTERVENTION *************************************/
/* stset the data with any intervention as failure type */
/* time1 is duration variable */
/* origin of analysis time is set to be minimum of time0, which has been offset to zero */
/* failure = 1 for oppinter, neutrality/censoring and govtinter are baselines */
/* exit when records run out for each id */
/* id variable is id */

stset time1, failure(anyinter==1) origin(time time0) time0(time0) exit(time .) id(id)
sts graph, hazard title("Estimated Baseline Hazard (All)", span justification(left)) ylabel(#5, angle(forty_five)) xlabel(0(1000)7000) 


/******************************* GENERATING HAZARD RATIOS FOR OPPOSITION INTERVENTION *************************************/
/* stset the data with intervention on opp as failure type */
/* time1 is duration variable */
/* origin of analysis time is set to be minimum of time0, which has been offset to zero */
/* failure = 1 for oppinter, neutrality/censoring and govtinter are baselines */
/* exit when records run out for each id */
/* id variable is id */
stset time1, failure(oppinter==1) origin(time time0) time0(time0) exit(time .) id(id)
sts graph, hazard title("Estimated Baseline Hazard (Opp.)", span justification(left)) ylabel(#5, angle(forty_five)) xlabel(0(1000)7000) 


/******************************* GENERATING HAZARD RATIOS FOR GOVT INTERVENTION *************************************/
/* stset the data with intervention on govt as failure type */
/* time1 is duration variable */
/* origin of analysis time is set to be minimum of time0, which has been offset to zero */
/* failure = 1 for govtinter, neutrality/censoring and oppinter are baselines */
/* exit when records run out for each id */
/* id variable is id */

stset time1, failure(govtinter==1) origin(time time0) time0(time0) exit(time .) id(id)
sts graph, hazard title("Estimated Baseline Hazard (Govt)", span justification(left)) ylabel(#5, angle(forty_five)) xlabel(0(1000)7000) 


*Combining the baseline hazards plots
gr combine anyinter.gph oppinter.gph govtinter.gph



/******************************* RE LOGIT MODEL *************************************/
***First Model: limiting to politically relevant dyads
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum allyconf rivalconf ethnic ideology jointdem ALLGEMP_C if relevant == 1
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C if e(sample)

*Generating predicted probability of intervention when gems = 0
setx(thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0475449 ALLGEMP_C 0
relogitq
*Baseline probability of 0.00351

*The following code estimates the first difference in probability moving from a value of 0 to a value of 1, holding all other values constant. It also generates the confidence interval around that estimate. 
setx(thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0475449
relogitq, fd(pr) changex(ALLGEMP_C 0 1)

*Difference is 0.0029, CI is 0.00071 to 0.0065139
*Used baseline probability from first model to calculate percent change
disp ((0.0029+0.00351)/0.00351) - 1

*use lower confidence interval to generate confidence interval in percent changes
disp ((0.00071+0.00351)/0.00351) - 1

*use upper confidence interval to generate confidence interval in percent changes
disp ((0.0065139+0.00351)/0.00351) - 1


***Second model: Analysis of politically relevant dyads with gems, diamonds, and drugs
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum allyconf rivalconf ethnic ideology jointdem gemsdrugs_C if relevant == 1
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C if e(sample)

*Generating predicted probability of intervention when gems and drugs = 0
setx (thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0475449 gemsdrugs_C 0
relogitq

*Baseline probability of 0.00357 

setx(thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0475449
relogitq, fd(pr) changex(gemsdrugs_C 0 1)

*Difference is 0.00250, CI is 0.00051 to 0.00602567
*Using baseline probability from second model to calculate percent change

disp ((0.00250+0.00357)/0.00357) - 1

*Using lower confidence interval to generate confidence interval in percent changes

disp ((0.00051 + 0.00357)/0.00357) - 1

*Using upper confidence interval to generate confidence interval in percent changes

disp ((0.00602567+0.00357)/0.00357) - 1


***Third Model: Opposition-biased intervention and rebel financing
relogit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum ethnic ideology jointdem fearonContraband  if relevant == 1
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband  if e(sample)

setx (thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0534635 fearonContraband 0
relogitq

*Baseline probability of 0.00194

setx(thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0534635
relogitq, fd(pr) changex(fearonContraband 0 1)

*Difference is 0.00172, CI is 0.000011 to .00521997
*Using the baseline probability
disp ((0.00172+0.00194)/0.00194) - 1

*Using the lower confidence interval

disp ((0.000011+0.00194)/0.00194) - 1

*Using the upper confidence interval

disp ((0.00521997+0.00194)/0.00194) - 1


***Fourth Model: Government-biased intervention and rebel financing
relogit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum ethnic ideology jointdem fearonContraband  if relevant == 1
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband  if e(sample)

setx (thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0534635 fearonContraband 0
relogitq

*Baseline probability of 0.00136

setx(thirdmajpow colhist coldwar sameregion contigdum rival allydum ethnic ideology jointdem) median logcapratio -0.0534635
relogitq, fd(pr) changex(fearonContraband 0 1)

*Difference is 0.00020, CI is -0.00053 to 0.00169284
*Using baseline probability 
disp ((0.00020+0.00136)/0.00136) - 1

*Using lower confidence interval
disp ((-0.00053+0.00136)/0.00136) - 1

*Using upper confidence interval
disp ((0.00169284+0.00136)/0.00136) - 1

/******************************* SPLIT-POPULATION/MIXTURE-CURE MODEL *************************************/
*** 5th model: All potential intervenors with gems and diamonds

set more off
stset time1, failure(anyinter==1) origin(time time0) time0(time0) exit(time .) id(id)
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyconf rivalconf logfatalities loglforced ALLGEMP_C)

***6th model: All potential interventors with gems, diamonds, and drugs

set more off
stset time1, failure(anyinter==1) origin(time time0) time0(time0) exit(time .) id(id)
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyconf rivalconf logfatalities loglforced gemsdrugs_C)

***7th model: Opposition-biased intervention and rebel financing

set more off
stset time1, failure(oppinter==1) origin(time time0) time0(time0) exit(time .) id(id)
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum logfatalities loglforced fearonContraband)

***8th model: Government-biased intervention and rebel financing

set more off
stset time1, failure(govtinter==1) origin(time time0) time0(time0) exit(time .) id(id)
cureregr thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband, dist(lognormal) class(mixture) link(logistic) scale(rival allydum allyongovtdum allyonoppdum rivalongovtdum rivalonoppdum logfatalities loglforced fearonContraband)


/******************************* MODELS FOR APPENDIX *************************************/
***Logit model with all potential interveners for robustness
*Logit model with all potential interveners with gems and diamonds
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C if e(sample)

*Logit with all potential interveners and all gems, diamonds, and drugs
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C if e(sample)

*Logit with opposition-biased interventions
logit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband, r
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)

*Logit with goverment-biased interventions
logit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband, r
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)

***Logit model with politically-relevant interveners for robustness
*Logit model with politically-relevant interveners and gems and diamonds
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C if relevant == 1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C if e(sample)

*Logit with politically-relevant interveners and all gems, diamonds, and drugs
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C if relevant == 1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C if e(sample)

*Logit with politically-relevant interveners and opposition-biased interventions
logit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if relevant == 1, r
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)

*Logit with politically-relevant interveners and goverment-biased interventions
logit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if relevant == 1, r
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)


***Rare Events Logit
*RE Logit model with all potential interveners with gems and diamonds
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_C if e(sample)

*RE Logit with all potential interveners with gems, diamonds, and drugs
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_C if e(sample)

*RE Logit with all potential intervener and opposition-biased interventions
relogit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)

*RE Logit with all potential intervener and goverment-biased interventions
relogit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContraband if e(sample)

***generate lagged variables***
gen ALLGEMP_Clag1 = ALLGEMP_C[_n-1]
gen gemsdrugs_Cslag1 = gemsdrugs_C[_n-1]
gen fearonContrabandlag1 = fearonContraband[_n-1]

****all lagged***
***Logit model with all potential interveners for robustness
*Logit model with all potential interveners with gems and diamonds
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag1 if e(sample)

*Logit with all potential interveners and all gems, diamonds, and drugs
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1 if e(sample)

*Logit with opposition-biased interventions
logit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1, r
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)

*Logit with goverment-biased interventions
logit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1, r
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)

***Logit model with politically-relevant interveners for robustness
*Logit model with politically-relevant interveners and gems and diamonds
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag if relevant == 1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag if e(sample)

*Logit with politically-relevant interveners and all gems, diamonds, and drugs
logit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1 if relevant == 1, r
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1 if e(sample)

*Logit with politically-relevant interveners and opposition-biased interventions
logit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if relevant == 1, r
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)

*Logit with politically-relevant interveners and goverment-biased interventions
logit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if relevant == 1, r
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)


***Rare Events Logit
*RE Logit model with all potential interveners with gems and diamonds
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem ALLGEMP_Clag if e(sample)

*RE Logit with all potential interveners with gems, diamonds, and drugs
relogit anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1
sum anyinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem gemsdrugs_Cslag1 if e(sample)

*RE Logit with all potential intervener and opposition-biased interventions
relogit oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1
sum oppinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)

*RE Logit with all potential intervener and goverment-biased interventions
relogit govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1
sum govtinter thirdmajpow colhist coldwar sameregion contigdum logcapratio rival allydum ethnic ideology jointdem fearonContrabandlag1 if e(sample)



*Title:   Replication Data for Harris/Findley JCR Paper on Ethnic Identifiability
*Authors: Adam Harris and Mike Findley
*Date:    July 11, 2012
*Version: Stata 12.1
*Notes:	  Create a folder, place all documents in the folder, and then set the path.
*For any questions please contact us at asharris4@gmail.com or mikefindley@austin.utexas.edu

clear

set more off

*preparing replication data

cd "SET LOCAL DIRECTORY HERE"

use "harris_findley_jcr.dta"

*Table 1: corret/incorrect classification
*Percent from tab command produces the percentages reported in table 1
*the tabs are performed by ethnic group in the order they appear in the table
*i.e. the first tab is based on the correct answer being Ndebele, the second Pedi, and so on.

forvalues i = 1/9 {
tab guess_specific if answer == `i'
}


*Table 2
logit guess strength_score first_name surname greet_own_lang greet_eng signal_own signal_own_sym signal_own_sym_oth signal_oth signal_oth_sym signal_oth_sym_own age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare, cluster (subject_num)


*Models reported in Table 3 (full covariates as reported in the Appendix)

*Models (1) - (5)
forvalues i = 1(1)5 {
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if cond_num == `i', cluster (subject_num)
}


*Models reported in Table 5 (full covariates as reported in the Appendix)

*Models (6) - (11)
forvalues i = 6(1)11 {
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if cond_num == `i', cluster (subject_num)
}


****************
*Appendix Tables
****************

*Summary Statistics
sum guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match


*Alternative Clustering

*Cluster on Ethnic Representer
*Models (1) - (11)
forvalues i = 1(1)11 {
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if cond_num == `i', cluster (ethnic_rep_num)
}

*Cluster on Subject-Representer Dyad
*Models (1) - (11)
forvalues i = 1(1)11 {
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if cond_num == `i', cluster (dyad_id)
}


*Pooling Conditions to Consider Joint Effects
*All sign conditions
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 1 | cond_num == 2 | cond_num == 3 | cond_num == 4 | cond_num == 5), cluster (ethnic_rep_num)
*All the signal conditions
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 6 | cond_num == 7 | cond_num == 8 | cond_num == 9 | cond_num == 10 | cond_num == 11), cluster (ethnic_rep_num)
*Signal conditions without symbols
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 6 | cond_num == 9), cluster (ethnic_rep_num)
*Signal conditions with symbols
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 7 | cond_num == 8 | cond_num == 10 | cond_num == 11), cluster (ethnic_rep_num)
*Signal conditions with supportive symbols
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 7 | cond_num == 10), cluster (ethnic_rep_num)
*Signal conditions with contradictory symbols
logit guess strength_score age gender schooling schooling_father schooling_mother years_in_mdantsane how_often_church ethnic_rep_age ethnic_rep_gender ethnic_rep_strength_score gender_match age_distance strength_match2 ethnicity_match order orderSquare if (cond_num == 8 | cond_num == 11), cluster (ethnic_rep_num)






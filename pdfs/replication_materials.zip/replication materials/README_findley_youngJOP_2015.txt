Replication Materials for JOP paper,	
"Spoilers, Terrorism, and the Resolution of Civil Wars"  
by Michael G. Findley and Joseph K. Young

Included materials:
1. This readme text file
2. duration.do—-a do-file to replicate duration of civil war models + figures
3. duration_main.dta—-data to replicate duration of civil war models + figures
4. recurrence.do—-a do file to replicate recurrence of civil war models + figures
5. recurrence_main.dta—-data to replicate recurrence of civil war models + figures
6. appendix.do—a do file to replicate extensions to main paper empirics and figures
7 + 8. duration_main_est.dta and recurrence_main_est.dta include estimates from the main model that will be used in appendix models. 

Please notify the authors if you need any additional materials or find any errors. All replication materials are available at https://dataverse.harvard.edu/dataverse/jyoung and www.michael-findley.com

mikefindley@utexas.edu

jyoung@american.edu
*********************************
* Mike Findley     				*
* Replication Commands 			*
* Date: May 2012   				*
*********************************

/* ============================ STAGE 1: WITH CONTROLS ================================== */
logit stage1 stalemate numbFaction peaceop rebStrength govtInterv opposInterv, robust	
	

/* ============================ STAGE 2: WITH CONTROLS ================================== */
logit stage2 stalemate numbFaction peaceop secureGuar govtInterv opposInterv powerSharing, robust


/* ============================ STAGE 3: WITH CONTROLS ================================== */
logit stage3 stalemate numbFaction peaceop secureGuar govtInterv opposInterv powerSharing, robust


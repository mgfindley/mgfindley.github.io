* King and Tomz *

net from http://gking.harvard.edu/clarify/
net install clarify

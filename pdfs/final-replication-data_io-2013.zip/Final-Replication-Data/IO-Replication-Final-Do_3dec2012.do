*********************************************************************************
* Do File to Evaluate the International Data for the Field Exp in IR Paper      *
* Published in International Organization, Year XXXX, Vol XX, Issue XX	        *
* Date: December 3, 2012							                            *
*********************************************************************************



clear
set more off

cd "SET PATH HERE"

log using "Field Experiments in IR.03dec12.smcl", replace
use "Field Experiments in IR.03dec12.dta", replace

*Replicate Table 1: Show raw tabulation counts and pr tests

*Test RESPONSE RATES
tab reply managerialcomparetab reply usorigincomparetab reply rationalcomparetab reply constructcompareprtest reply, by(managerialcompare)prtest reply, by(usorigincompare)prtest reply, by(rationalcompare)prtest reply, by(constructcompare)
*Test NON-compliance 
tab noncompliant1 managerialcompare
tab noncompliant1 usorigincompare
tab noncompliant1 rationalcompare
tab noncompliant1 constructcompare

prtest noncompliant1, by(managerialcompare)
prtest noncompliant1, by(usorigincompare)
prtest noncompliant1, by(rationalcompare)
prtest noncompliant1, by(constructcompare)

**Test PARTIAL compliance 
tab partcompliant1 managerialcompare
tab partcompliant1 usorigincompare
tab partcompliant1 rationalcompare
tab partcompliant1 constructcompare

prtest partcompliant1, by(managerialcompare)
prtest partcompliant1, by(usorigincompare)
prtest partcompliant1, by(rationalcompare)
prtest partcompliant1, by(constructcompare)

*Test compliance 
tab compliant1 managerialcompare
tab compliant1 usorigincompare
tab compliant1 rationalcompare
tab compliant1 constructcompare

prtest compliant1, by(managerialcompare)
prtest compliant1, by(usorigincompare)
prtest compliant1, by(rationalcompare)
prtest compliant1, by(constructcompare)

*Test REFUSAL 
tab refusal1 managerialcompare
tab refusal1 usorigincompare
tab refusal1 rationalcompare
tab refusal1 constructcompare

prtest refusal1, by(managerialcompare)
prtest refusal1, by(usorigincompare)
prtest refusal1, by(rationalcompare)
prtest refusal1, by(constructcompare)


**Replicate Figure 2: Show outcome proportions and differences from placebo

* Create twoway bar graph with error bars below

use "Field Exp in IR Treatment Bar Chart Data.3Dec12.dta", clear

twoway (bar mean treatout if treatment==1) /// 
       (bar mean treatout if treatment==2) /// 
       (bar mean treatout if treatment==3) /// 
       (bar mean treatout if treatment==4) /// 
       (bar mean treatout if treatment==5) /// 
       (rcap hivalue lovalue treatout), ///
       legend(row(1) order(1 "Placebo" 2 "Managerial" 3 "U.S." 4 "Rational" 5 "Construct") ) ///
       xlabel( 3 "Non-Compliant" 9 "Part-Compliant" 15 "Compliant" 21 "Refusal" 27 "No Response", noticks) ///
       xtitle("Outcome Measures") ytitle("Proportion") ///
       name(panela, replace) nodraw
       
twoway (dot testdiff treatout if treatment==1) /// 
       (dot testdiff treatout if treatment==2) /// 
       (dot testdiff treatout if treatment==3) /// 
       (dot testdiff treatout if treatment==4) /// 
       (dot testdiff treatout if treatment==5) /// 
       (rcap highci lowci treatout), ///
       legend(row(1) order(1 " " 2 "Managerial" 3 "U.S." 4 "Rational" 5 "Construct") ) ///
       xlabel( 3 "Non-Compliant" 9 "Part-Compliant" 15 "Compliant" 21 "Refusal" 27 "No Response", noticks) ///
       xtitle("Outcome Measures") ytitle("Difference from Placebo") ///
       name(panelb, replace) nodraw
       
graph combine panela panelb, cols(1)       
gr_edit plotregion1.graph1.plotregion1.plot6.draw_view.setstyle, style(no)
gr_edit plotregion1.graph2.plotregion1.plot6.style.editstyle area(linestyle(color(black))) editcopy
gr_edit plotregion1.graph2.plotregion1.plot6.style.editstyle area(linestyle(width(thin))) editcopy
gr_edit plotregion1.graph2.plotregion1.plot6.style.editstyle marker(size(small)) editcopy
gr_edit plotregion1.graph2.legend.draw_view.setstyle, style(no)





**Replicate Table 2: Show multinomial probit results across conditions

clear
set more off

use "Field Experiments in IR.03dec12.dta", replace

*USE NO RESPONSE AS BASE CONDITION
mprobit multioutcome managerialcompare2, r base(0)
mprobit multioutcome usorigincompare2, r base(0)
mprobit multioutcome rationalcompare2, r base(0)
mprobit multioutcome constructcompare2, r base(0)


**Replicate Table 3: Show selection model results across conditions

* ALL TREATMENTS
sartsel sartoricomply managerialcompare2, corr(1)
sartsel sartoricomply usorigincompare2, corr(1)
sartsel sartoricomply rationalcompare2, corr(1)
sartsel sartoricomply constructcompare2, corr(1)


********************************************************************************
********************************************************************************
*Appendix: Replication of multinomial logit results

*use "Field Experiments in IR.03dec12.dta", replace

mlogit multioutcome managerialcompare2, r base(0)
mlogit multioutcome usorigincompare2, r base(0)
mlogit multioutcome rationalcompare2, r base(0)
mlogit multioutcome constructcompare2, r base(0)



log close


